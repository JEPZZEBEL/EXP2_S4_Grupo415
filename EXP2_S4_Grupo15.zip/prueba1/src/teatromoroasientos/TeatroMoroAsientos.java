package teatromoroasientos;

import java.util.Scanner;

public class TeatroMoroAsientos {

    public static void main(String[] args) {

        Scanner opcionScanner;
        Scanner zonaScanner;
        Scanner asientoAScanner;
        Scanner asientoBScanner;
        Scanner asientoCScanner;
        Scanner edadScanner;
        try (Scanner inicioScanner = new Scanner(System.in)) {
            opcionScanner = new Scanner(System.in);
            zonaScanner = new Scanner(System.in);
            asientoAScanner = new Scanner(System.in);
            asientoBScanner = new Scanner(System.in);
            asientoCScanner = new Scanner(System.in);
            edadScanner = new Scanner(System.in);
            int inicio;
            int opcion;
            int zona;
            int edad;
            int entrada = 20000;
            int subtotal;
            int total = 0;
            int asientoA;
            int asientoB;
            int asientoC;
            int asiento = 0;
            // Entrada del sistema.
            System.out.println("## BIENVENIDO AL SISTEMA DEL TEATRO MORO ##");
            System.out.println("    ");
            // Para iniciar el sistema se debe presionar 1, de lo contrario, sale del programa.
            System.out.println("- comprar entradas, presione: 1");
            System.out.println("- salir presione: cualquier tecla.");
            System.out.println("    ");
            inicio = inicioScanner.nextInt();
            if (inicio == 1) {
                do {
                    
                    do {
                        System.out.println("    ");
                        System.out.println("Indique la zona que desea:");
                        System.out.println("1: zona A, 2: zona B, 3: zona C");
                        
                        // se pide zona valida entre 1 y 3 de lo contrario vuelve a pedir una zona valida.
                        zona = zonaScanner.nextInt();
                        switch (zona) {
                            case 1 -> {
                                do {
                                    System.out.println("    ");
                                    System.out.println("Ha elejido la zona: A.");
                                    System.out.println("    ");
                                    System.out.println("Elija el asiento que desee:");
                                    System.out.println("    ");
                                    System.out.println("- [ ZONA A ] --------------- ZONA B -------------------- ZONA C --");
                                    System.out.println("1: asiento 01 ----------- 1: asiento 01 ------------- 1: asiento 01");
                                    System.out.println("2: asiento 02 ----------- 2: asiento 02 ------------- 2: asiento 02");
                                    System.out.println("3: asiento 03 ----------- 3: asiento 03 ------------- 3: asiento 03");
                                    System.out.println("4: asiento 04 ----------- 4: asiento 04 ------------- 4: asiento 04");
                                    System.out.println("5: asiento 05 ----------- 5: asiento 05 ------------- 5: asiento 05");
                                    System.out.println("    ");

                                    // se pide un asiento valido entre 1 y 5, de lo contrario vuelve a pedir un asiento valido.
                                    asientoA = asientoAScanner.nextInt();
                                    if (asientoA > 0 && asientoA <= 5) {
                                        System.out.println("    ");
                                        System.out.println("Ha seleccionado el asiento:" + " " + asientoA);
                                        System.out.println("    ");
                                        
                                        // asigno el numero de asiento para mostrarlo en la salida.
                                        asiento = asientoA;
                                        
                                    } else {
                                        System.out.println("    ");
                                        System.out.println("Asiento:" + " " + asientoA + " " + "no esta disponible, vuelva a intentarlo.");
                                    }
                                    
                                } while (asientoA < 1 || asientoA > 5);
                            }
                            case 2 -> {
                                do {
                                    System.out.println("    ");
                                    System.out.println("Ha elejido al zona: B.");
                                    System.out.println("    ");
                                    System.out.println("Elija el asiento que desee:");
                                    System.out.println("    ");
                                    System.out.println("-- ZONA A ----------------- [ ZONA B ] ----------------- ZONA C --");
                                    System.out.println("1: asiento 01 ----------- 1: asiento 01 ------------- 1: asiento 01");
                                    System.out.println("2: asiento 02 ----------- 2: asiento 02 ------------- 2: asiento 02");
                                    System.out.println("3: asiento 03 ----------- 3: asiento 03 ------------- 3: asiento 03");
                                    System.out.println("4: asiento 04 ----------- 4: asiento 04 ------------- 4: asiento 04");
                                    System.out.println("5: asiento 05 ----------- 5: asiento 05 ------------- 5: asiento 05");
                                    System.out.println("    ");
                                    
                                    // se pide un asiento valido entre 1 y 5, de lo contrario vuelve a pedir un asiento valido.
                                    asientoB = asientoBScanner.nextInt();
                                    if (asientoB > 0 && asientoB <= 5) {
                                        System.out.println("    ");
                                        System.out.println("Ha seleccionado el asiento:" + " " + asientoB);
                                        System.out.println("    ");
                                        
                                        // asigno el numero de asiento para mostrarlo en la salida.
                                        asiento = asientoB;
                                        
                                    } else {
                                        System.out.println("    ");
                                        System.out.println("Asiento:" + " " + asientoB + " " + "no esta disponible, vuelva a intentarlo.");
                                    }
                                    
                                } while (asientoB < 1 || asientoB > 5);
                            }
                            case 3 -> {
                                do {
                                    System.out.println("    ");
                                    System.out.println("Ha elejido la zona: C.");
                                    System.out.println("    ");
                                    System.out.println("Elija el asiento que desee:");
                                    System.out.println("    ");
                                    System.out.println("-- ZONA A ------------------ ZONA B ------------------ [ ZONA C ] -");
                                    System.out.println("1: asiento 01 ----------- 1: asiento 01 ------------- 1: asiento 01");
                                    System.out.println("2: asiento 02 ----------- 2: asiento 02 ------------- 2: asiento 02");
                                    System.out.println("3: asiento 03 ----------- 3: asiento 03 ------------- 3: asiento 03");
                                    System.out.println("4: asiento 04 ----------- 4: asiento 04 ------------- 4: asiento 04");
                                    System.out.println("5: asiento 05 ----------- 5: asiento 05 ------------- 5: asiento 05");
                                    System.out.println("    ");
                                    // se pide un asiento valido entre 1 y 5, de lo contrario vuelve a pedir un asiento valido.
                                    asientoC = asientoCScanner.nextInt();
                                    if (asientoC > 0 && asientoC <= 5) {
                                        System.out.println("    ");
                                        System.out.println("Ha seleccionado el asiento:" + " " + asientoC);
                                        System.out.println("    ");
                                        
                                        // asigno el numero de asiento para mostrarlo en la salida.
                                        asiento = asientoC;
                                        
                                    } else {
                                        System.out.println("    ");
                                        System.out.println("Asiento:" + " " + asientoC + " " + "no esta disponible, vuelva a intentarlo.");
                                    }
                                    
                                } while (asientoC < 1 || asientoC > 5);
                            }
                            default -> {
                                System.out.println("    ");
                                System.out.println("La opcion es incorrecta, vuelva a intentarlo.");
                                System.out.println("    ");
                            }
                        }
                    } while (zona < 1 || zona > 3);
                    
                    System.out.println("Indique su edad:");
                    edad = edadScanner.nextInt();
                    
                    if (edad <= 17) {
                        System.out.println("    ");
                        System.out.println("ud posee un descuento del 10% por cada entrada.");
                        subtotal = (int) (entrada * 0.9);
                    } else if (edad >= 60) {
                        System.out.println("    ");
                        System.out.println("ud posee un descuento del 15% por cada entrada.");
                        subtotal = (int) (entrada * 0.85);
                        
                    } else {
                        subtotal = entrada;
                    }
                    
                    // sumo el subtotal cada vez que vuelve a comprar entradas y lo asigno a la variable total.
                    total += subtotal;
                    
                    // salida de información.
                    System.out.println("    ");
                    switch (zona) {
                        case 1 -> System.out.println("- ubicacion: ZONA A" + " - " + "asiento: " + asiento);
                        case 2 -> System.out.println("- ubicacion: ZONA B" + " - " + "asiento: " + asiento);
                        default -> System.out.println("- ubicacion: ZONA C" + " - " + "asiento: " + asiento);
                    }
                    
                    System.out.println("- precio normal:" + " " + "$" + entrada);
                    
                    // si la edad aplica para el descuento, se muestra este mensaje.
                    if (edad <= 17 || edad >= 60) {
                        System.out.println("- precio con descuento aplicado:" + " " + "$" + subtotal);
                    }
                    
                    System.out.println("- total a pagar es:" + " " + "$" + total);
                    System.out.println("    ");
                    
                    // consulta para volver a comprar o salir.
                    System.out.println(" Desea hacer otra compra?");
                    System.out.println("1: Si");
                    System.out.println("2: No");
                    
                    /* si la opcion es 1 vuelve al inicio para hacer la compra, si es 2, sale del programa,
                    de lo contrario indica que la opcion no es valida y vuelve a consultar por la opcion valida. */
                    opcion = opcionScanner.nextInt();
                    if (opcion < 1 || opcion > 2) {
                        System.out.println("    ");
                        System.out.println("La opcion es incorrecta, vuelva a intentarlo.");
                        System.out.println("    ");
                    }
                    
                } while (opcion == 1);
                // salida en caso de que el usuario envia la opcion 2 para salir.
                System.out.println("    ");
                System.out.println("Gracias por su compra!!");
            } else {
                System.out.println("Saliendo del sistema.");
            }
            // cierre variables scanner
        }
        opcionScanner.close();
        zonaScanner.close();
        asientoAScanner.close();
        asientoBScanner.close();
        asientoCScanner.close();
        edadScanner.close();
    }
}
